/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int a,b;
    int *p =NULL;
    
    p=&a;
    *p = 5;
    
    p = &b;
    printf("Enter an integer: ");
    scanf("%d", p); // Read an integer and store it in the memory location pointed to by p
   
    printf("a=%d,\tb=%d\n", a, b);
    return 0;
}