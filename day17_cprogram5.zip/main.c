/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*WEIGTH CONVERSION PROMBLEM*/
#include <stdio.h>
void convert(float,float*,float*,float*);
int main()
{
float kg,gm,ton,pound;

printf("\nEnter weigth in kilograms:");
scanf("%f",&kg)
convert(kg,&gm,ton,&pound);
printf("kg=%f\n,"kg);
printf("Gm=%f Tonne=%f Pounds=%f\n",gm,ton,pound);
return 0;

}
 void convert(float kg,float *g ,float*t,float*p)
 {
     *g=kg*1000;
     *t=kg*0.001;
     *p=kg*2.204;
     }