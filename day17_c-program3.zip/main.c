/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
 float a=13.5;
 float *b,*c;
 b=&a; /*suppose address of a is 1006*/
 c=b;
 printf("%u%u%u\n",&a,b,c);
 printf("%f%f%f%f%f\n",a*(&a),*&a,*b,*c);

    return 0;
}
