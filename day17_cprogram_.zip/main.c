/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

void fun(int,int);
int main()
{
    int i=5,j=2;
    fun(i,j);
    printf("%d%d\n",i,j);
    return 0;
}
void fun(int i,int j)
{
    i=i*i;
    j=j*j;
    
}