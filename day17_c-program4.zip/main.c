/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*Circular shifting of values*/

#include <stdio.h>
void fun(int,int,int);

int main()
{
    int x,y,z;
 printf("Enter the values x,y,z:\n");
 scanf("%d%d%d",&x,&y,&z);
 printf("\n ValueN of x,y &z as entered");
 printf("\nx=%d\ty=%d\tz=%d\n",x,y,z);
 fun(x,y,z);
 return 0;

}
/*FUNCTION TO  SHIFT VALUES OF X,Y & Z */

void fun(int x,int y,int z)
{
    int i,t;
    for(i=0; i<=2; i++)
    {
        t=z;
        z=y;
        y=x;
        x=t;
        printf("\n After rigth shifting %d time(s):\n",i+1);
        printf("x=%d\ty=%d\tz=%d",x,y,z);
    }
}