/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a=5;
    int *p=NULL;
    p = &a;
    printf("The address of the variable a: %x\n",&a);
    printf("The content of the variable p: %x\n",p);
    printf("The content of the variable a: %d\n",a);
    printf("The content of the variable p points to : %d\n",*p);
    printf("The addrezss of the pointer variable :%x\n",&p);
    return 0;
}
